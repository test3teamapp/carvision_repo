
# Hello!

This is a simple and reliable C implementation of the Gilbert-Johnson-Keerthi (GJK) algorithm, [docs and  details are available here](https://www.mattiamontanari.com/opengjk/). 

All contributes are all welcome. For instance you could add:
 - Support for other shapes: quadrics and splines (easy)
 - More python examples and test (easy)
 - EPA algorithm (hard)

>   openGJK, Copyright (c) 2018-2021
>   
>   Department of Engineering Science. University of Oxford, UK.
